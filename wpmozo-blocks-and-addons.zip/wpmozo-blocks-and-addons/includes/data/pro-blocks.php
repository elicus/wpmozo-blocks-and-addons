<?php
/**
 * Blocks and addon all pro blocks list.
 */

defined( 'ABSPATH' ) || exit;

return array(
	'accordion-slider'                 => esc_html__( 'Accordion Slider', 'wpmozo-blocks-and-addons' ),
	'advanced-counter'                 => esc_html__( 'Advanced Counter', 'wpmozo-blocks-and-addons' ),
	'advanced-table'                   => esc_html__( 'Advanced Table', 'wpmozo-blocks-and-addons' ),
	'advanced-tabs'                    => esc_html__( 'Advanced Tabs', 'wpmozo-blocks-and-addons' ),
	'ajax-search'                      => esc_html__( 'AJAX Search', 'wpmozo-blocks-and-addons' ),
	'alert-box'                        => esc_html__( 'Alert Box', 'wpmozo-blocks-and-addons' ),
	'audio-player'                     => esc_html__( 'Audio Player', 'wpmozo-blocks-and-addons' ),
	'bar-chart'                        => esc_html__( 'Bar Chart', 'wpmozo-blocks-and-addons' ),
	'blog-categories'                  => esc_html__( 'Blog Categories', 'wpmozo-blocks-and-addons' ),
	'blog-slider'                      => esc_html__( 'Blog Slider', 'wpmozo-blocks-and-addons' ),
	'comparison-list'                  => esc_html__( 'Comparison List', 'wpmozo-blocks-and-addons' ),
	'coupon'                           => esc_html__( 'Coupon', 'wpmozo-blocks-and-addons' ),
	'dynamic-gallery'                  => esc_html__( 'Dynamic Gallery', 'wpmozo-blocks-and-addons' ),
	'facebook-embedded-post'           => esc_html__( 'Facebook Embedded Post', 'wpmozo-blocks-and-addons' ),
	'facebook-page'                    => esc_html__( 'Facebook Page', 'wpmozo-blocks-and-addons' ),
	'gravity-form-styler'              => esc_html__( 'Gravity Form Styler', 'wpmozo-blocks-and-addons' ),
	'hero-slider'                      => esc_html__( 'Hero Slider', 'wpmozo-blocks-and-addons' ),
	'horizontal-scrolling-card'        => esc_html__( 'Horizontal Scrolling Card', 'wpmozo-blocks-and-addons' ),
	'image-card-carousel'              => esc_html__( 'Image Card Carousel', 'wpmozo-blocks-and-addons' ),
	'image-hotspot'                    => esc_html__( 'Image Hotspot', 'wpmozo-blocks-and-addons' ),
	'instagram-feed'                   => esc_html__( 'Instagram Feed', 'wpmozo-blocks-and-addons' ),
	'instagram-feed-carousel'          => esc_html__( 'Instagram Feed Carousel', 'wpmozo-blocks-and-addons' ),
	'interactive-circle'               => esc_html__( 'Interactive Circle', 'wpmozo-blocks-and-addons' ),
	'marquee-text'                     => esc_html__( 'Marquee Text', 'wpmozo-blocks-and-addons' ),
	'modal-popup'                      => esc_html__( 'Modal Popup', 'wpmozo-blocks-and-addons' ),
	'pie-chart'                        => esc_html__( 'Pie Chart', 'wpmozo-blocks-and-addons' ),
	'svg-animator'                     => esc_html__( 'SVG Animator', 'wpmozo-blocks-and-addons' ),
	'table-of-contents'                => esc_html__( 'Table of Contents', 'wpmozo-blocks-and-addons' ),
	'team-grid'                        => esc_html__( 'Team Grid', 'wpmozo-blocks-and-addons' ),
	'testimonial-grid'                 => esc_html__( 'Testimonial Grid', 'wpmozo-blocks-and-addons' ),
	'text-hover-effects'               => esc_html__( 'Text Hover Effects', 'wpmozo-blocks-and-addons' ),
	'text-with-media'                  => esc_html__( 'Text With Media', 'wpmozo-blocks-and-addons' ),
	'timeline'                         => esc_html__( 'Timeline', 'wpmozo-blocks-and-addons' ),
	'woo-brands-carousel'              => esc_html__( 'Woo Brands Carousel', 'wpmozo-blocks-and-addons' ),
	'woo-product-carousel'             => esc_html__( 'Woo Product Carousel', 'wpmozo-blocks-and-addons' ),
	'woo-product-categories'           => esc_html__( 'Woo Product Categories', 'wpmozo-blocks-and-addons' ),
	'woo-product-categories-carousel'  => esc_html__( 'Woo Product Categories Carousel', 'wpmozo-blocks-and-addons' ),
	'woo-product-gallery'              => esc_html__( 'Woo Product Gallery', 'wpmozo-blocks-and-addons' ),
	'woo-product-grid'                 => esc_html__( 'Woo Product Grid', 'wpmozo-blocks-and-addons' ),
	'woo-products-accordion'           => esc_html__( 'Woo Product Accordion', 'wpmozo-blocks-and-addons' ),
);
